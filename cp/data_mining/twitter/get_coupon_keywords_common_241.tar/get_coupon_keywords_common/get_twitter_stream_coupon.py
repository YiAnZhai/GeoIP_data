# -*- coding: utf-8 -*-
#Import the necessary methods from tweepy library
from tweepy.streaming import StreamListener
from tweepy import OAuthHandler
from tweepy import Stream
import time


#coupon_bbb       241 coupon
access_token = "785342528618795008-tP0ncyu54NeweKTn7t6sQtuCpRbf4yu"
access_token_secret = "0ekXWovdmbnK53BrFlX53gQqpqxcvMBpBWgwo7fKLoxmt"
consumer_key = "SFT5tOrUME1b55OZBGrzJvstu"
consumer_secret = "mTeer1PFDBc3jDRpszavNV6BVz107rzZDdy0VpWABRpqX9j2Vc"


#This is a basic listener that just prints received tweets to stdout.
class StdOutListener(StreamListener):

    def on_data(self, data):
        print data
        return True

    def on_error(self, status):
        # print status
        raise Exception(status)
        pass

if __name__ == '__main__':
    while True:
        try:

            l = StdOutListener()
            auth = OAuthHandler(consumer_key, consumer_secret)
            auth.set_access_token(access_token, access_token_secret)
            stream = Stream(auth, l)
#            #This handles Twitter authetification and the connection to Twitter Streaming API
#            #This line filter Twitter Streams to capture data by the keywords: 'coupon', 'discount', coupon_code

#	    off_percent_list = ['%s%s off' % (i, "%") for i in range(1, 100)] + ["$%s off" % (i) for i in range(100)]
#	    track_list = off_percent_list + ['free off','discount off']
# 	    track_list = ['promo code','coupon code','deals code','discount code', 'code free', 'code off']
            track_list = ['code','off','coupon','coupons','codes','promo','promocode','discount','discounts','couponcode','sale','sales','deal','deals']
	    stream.filter(track=track_list, languages=["en"])
#	    stream.filter(track=track_list)

        except Exception, e:
            time.sleep(90)
            pass
            # print "error: ", e
