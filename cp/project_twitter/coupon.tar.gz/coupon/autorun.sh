export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games

python identify_coupon_fresh.py
python twitter_json_todb.py 
python getcode_discount.py 
