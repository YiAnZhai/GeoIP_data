# -*- coding: utf-8 -*-
import re
from HTMLParser import HTMLParser
def get_discount(text):
		result = ""
		pattern = re.compile(r"(\$?\s?[\d\.]{1,6}%?)\s(off|discount|free)", re.I)
		discount_re = pattern.findall(text)
		if discount_re:
				# result = ";".join([a[0].strip(",.:)(\'\"` \n") for a in discount_re])
				result = discount_re[0][0]
		else:
				pattern2 = re.compile(r"(save|up\s*to)\s*(\$?\s?[\d\.]{1,6}%?)", re.I)
				discount_re2 = pattern2.findall(text)
				if discount_re2:
						result = discount_re2[0][1]
		result = re.sub(r" ", "", result.strip(",.:)(\'\"` \n"))
		if result.isdigit():
				result = ""
		return result




def get_code(text):
		text_a, num = re.subn("code", "CODe", text, flags=re.I)
		text_a, num = re.subn("use", "USe", text_a, flags=re.I)
		text_a, num = re.subn("using", "USIng", text_a, flags=re.I)
		text_a, num = re.subn("coupon", "COUPOn", text_a, flags=re.I)
		result = ""
		pattern = re.compile(r"""(CODe\s+'([\S]+)')|(CODe\s+"([\S]+)")|(CODe:\s?([\S]+))|(CODe\s+([0-9A-Z]+)([,\.!]|\s|$))|\"([0-9A-Z]+)\"|USe[SsDd]?[:\s\'\"]+([0-9A-Z]+)([,\.!]|\s|$)|USIng[:\s\'\"]+([0-9A-Z]+)([,\.!]|\s|$)|COUPOns?[:\s\'\"]+([0-9A-Z]+)([,\.!]|\s|$)""")
		code_re = pattern.search(text_a)
		if code_re:
				if code_re.group(2):
						result = code_re.group(2)
				elif code_re.group(4):
						result = code_re.group(4)
				elif code_re.group(6):
						result = code_re.group(6)
				elif code_re.group(8):
						result = code_re.group(8)
				elif code_re.group(10):
						result = code_re.group(10)
				elif code_re.group(11):
						result = code_re.group(11)
				elif code_re.group(13):
						result = code_re.group(13)
				elif code_re.group(15):
						result = code_re.group(15)

		result = result.strip(",.:)(\'\"` \n").encode('ascii','ignore')
		result_list = result.split(r"\n")
		for result_i in result_list:
			if result_i and not result_i.isdigit():
				return result_i
		return ""


def check_freeshipping(text):
		if "free ship" in text.lower():
				return 1
		return 0


def del_linkat(text):
		result_dellink, num_dellink = re.subn(r"(http(s)?)[\S]+(\s)?", "", HTMLParser().unescape(text).encode('ascii','ignore'))
		result_delat, num_delat = re.subn(r"(RT |Via |on |in |with |at |by )?@[\S]+(:|\s)?", " ", result_dellink)
		# result_delat = re.sub(u"[=❤<>�♢♠◕♧♯»✔★]…", " ", result_delat.lstrip(u"*^+?\.[]^|)}~!/@£%&=`´;><: ❤�♢♠◕♧♯»✔★"))
		# print result_delat
		result_delat = re.sub(r"(#[^\s]+\s*)$", "", result_delat)
		result_delat = re.sub(r" RT ", " ", result_delat)
		result_delat = re.sub(r"(\?{2,})|(_{2,})|(\-{2,})", " ", result_delat)
		result_delat = re.sub(r"\s+", " ", result_delat.strip())
		return result_delat



def word_sep(tweet):
	emoticons_str = r"""
	    (?:
	        [:=;] # Eyes
	        [oO\-]? # Nose (optional)
	        [D\)\]\(\]/\\OpP] # Mouth
	    )"""

	regex_str = [
	    emoticons_str,
	    r'<[^>]+>', # HTML tags
	    r'(?:@[\w_]+)', # @-mentions
	    r"(?:\#+[\w_]+[\w\'_\-]*[\w_]+)", # hash-tags
	    r'http[s]?://(?:[a-z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-f][0-9a-f]))+', # URLs

	    r'(?:[%\$])',
	#    r'(?:[%])',
	    r'(?:(?:\d+,?)+(?:\.?\d+)?)', # numbers
	    r"(?:[a-z][a-z'\-_]+[a-z])", # words with - and '
	    r'(?:[\w_]+)', # other words
	    r'(?:\S)' # anything else
	]

	tokens_re = re.compile(r'('+'|'.join(regex_str)+')', re.VERBOSE | re.IGNORECASE)
	emoticon_re = re.compile(r'^'+emoticons_str+'$', re.VERBOSE | re.IGNORECASE)

	result = tokens_re.findall(tweet)
	return result