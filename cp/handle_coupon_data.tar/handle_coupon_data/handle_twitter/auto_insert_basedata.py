# -*- coding: utf-8 -*-
import os
import time

while True:
	os.system("python check_info_autorunstart.py")
	print "handle data finish one day            " * 20
	time.sleep(100)