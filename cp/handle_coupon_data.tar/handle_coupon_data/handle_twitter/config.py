#########db info
DB_HOST = "localhost"
DB_NAME = "coupon_datacenter"
DB_USER = "root"
DB_PSWD = "moma"
CHARSET = "utf8"

#########tables
negative_domain_table = "negative_domain"
negative_domain_reviewed_table = "negative_domain_reviewed"
negative_domain_reviewing_table = "negative_domain_reviewing"
negative_domain_revieweveryday_table = "negative_domain_to_revieweveryday"
negative_domain_competitor_revieweveryday_table = "negative_domain_competitor_to_revieweveryday"
needhandled_domain_table = "needhandled_domain"
domain_whitebrand_list = "white_brand_domain"
domain_whitebrand_reviewed_list = "white_brand_domain_reviewed"
domain_whitebrand_needreviewed_list = "white_brand_domain_to_revieweveryday"
twitter_user_table = "tweet_user"

red_url_table = "get_red_url"
domain_red_url_table = "get_domain_titledescription"


couponinfo_table = "twitter_coupon_info"
couponinfohandle_table = "twitter_coupon_info_handle"
couponinfohandle_all_table = "twitter_coupon_info_handle_all"
couponblackpending_table = "twitter_coupon_black_pending"
couponblacklist_table = "twitter_coupon_blackdestination"
couponneedhandled_list_table = "twitter_coupon_handleneeded_domain"
couponneedhandled_list_all_table = "twitter_coupon_handleneeded_domain_all"


dup_base_table = "coupon_twitter_today_copy"
dup_baseall_table = "coupon_twitter_today_copy_all"
dup_basenegwordall_table = "coupon_twitter_today_copy_allnegword"

dup_after_all_table = "coupon_twitter_chijiao"
dup_remove_table = "coupon_twitter_today_remdup"

dup_innertwitter_table = "coupon_twitter_innertwitter"
dup_innertwitterall_table = "coupon_twitter_innertwitter_all"


twitter_etsy_table = "coupon_twitter_z_etsy"
twitter_instagram_table = "coupon_twitter_z_instagram"
twitter_linkis_table = "coupon_twitter_z_linkis"
twitter_constantcontact_table = "coupon_twitter_z_constantcontact"
twitter_campaign_table = "coupon_twitter_z_campaign"

###
dup_innertwitter_test_history_table = "coupon_twitter_innertwitter_test_historydup"


coupon_twitter_table = "coupon_twitter"
coupon_retail_api_table = "coupon_api"

twitter_expand_domain_table = "twitter_domains_expand"
twitter_destination_domain_table = "twitter_domains_destination"


#########fields
handle_to_black_commonfileds = """guid, user_id, text, clean_text, code, discount, freeshipping, tweet_id, expand_url, expand_domain, url, display_url, user_mention, hashtag, retweet_count, favorite_count, create_time, create_time_format, update_time, update_time_format"""
handle_to_all_fields = """guid, user_id, text, clean_text, code, discount, freeshipping, tweet_id, expand_url, expand_domain, url, display_url, user_mention, hashtag, retweet_count, favorite_count, create_time, create_time_format, update_time, update_time_format"""

dupremove_fields = """brand, `code`, title, description, source, url, restriction, linkid, start_date, end_date, adddate, advertiserid, redirect_url, landing_page, url_status, category, keywords, htmlofdeal, promotiontypes, freeshipping, discount, guid, advertisername, retweet_count, favorite_count"""
# dupwithapi_fields = "brand, `code`, title, description, source, url, restriction, linkid, start_date, end_date, adddate, advertiserid, redirect_url, landing_page, url_status, category, keywords, htmlofdeal, promotiontypes, freeshipping, discount, guid, advertisername"

twitter_today_copy_toall = "source, advertiserid, brand, title, description, code, end_date, start_date, category, restriction, keywords, htmlofdeal, promotiontypes, adddate, freeshipping, discount, guid, advertisername, linkid, redirect_url, landing_page, url_status, url, retweet_count, favorite_count"
twitter_innercoupon_toall = "source, advertiserid, brand, title, description, code, end_date, start_date, category, restriction, keywords, htmlofdeal, promotiontypes, adddate, freeshipping, discount, guid, advertisername, linkid, redirect_url, landing_page, url_status, url, retweet_count, favorite_count"


##########suffix that seldom seen
exception_suffix = set(["uk.com"])


##########negative word in tweet text
negative_words = set(["fuck","fucking","shit","ass","bastard","bitch","cock","cunt","dick","damn","nigger",])
########		"associate","association","dickies","assistant","assortment","assembly","assembled",
########		"assure","assurance","assist","Cockpit","dick's","Assorted","asse%","cocktail","assy"])

#########porn word in domain title and description
porn_words = ["porn","sex","anal","pussy","lesbian","fuck","xxx","adult,video",
	"ass","tits","porno","japanese,video","creampie", "hentai", "orgasm",
	"fucking", "blowjob", "naked", "cock", "boobs", "gangbang", "handjob",
	"interracial"]


###########review black and white domain or not, *****The older data keeped when turn off******
review_whitedomain = False
review_blackdomain = True
review_competitordomain = True
###########black domain everyday
count_reviewblack_domains=10
count_reviewblack_nurls=10
###########white subdomain everyday
count_review_tld=30
count_review_url=10
###########competitor domain everyday
count_review_domain = 1000000
